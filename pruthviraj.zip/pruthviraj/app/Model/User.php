<?php
App::uses('AppModel', 'Model');
App::uses('BlowfishPasswordHasher', 'Controller/Component/Auth');

class User extends AppModel {
    public $validate = array(
        'username' => array(
            'required' => array(
                'rule' => 'notBlank',
                'message' => 'A username is required'
            )
        ),        
        'password' => array(
            'required' => array(
                'rule' => 'notBlank',
                'message' => 'A password is required'
            )
        )
    );
    
  
    var $belongsTo = array(
        'Language' => array(
            'className'=>'Language',
            'fields' => array('id'),
            'foreignKey' => 'language_id'
        )
    );
 
    
   public function beforeSave($options = array()) {
       
        if (isset($this->data[$this->alias]['password'])) {
            $this->data[$this->alias]['password'] = AuthComponent::password($this->data[$this->alias]['password']);
        }

        return parent::beforeSave($options);
    }
}