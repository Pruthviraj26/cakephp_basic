<?php
App::uses('AppModel', 'Model');
class Banner extends AppModel {
}