<?php
App::uses('AppModel', 'Model');
class News extends AppModel {
}