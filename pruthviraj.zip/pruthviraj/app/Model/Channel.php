<?php
App::uses('AppModel', 'Model');
class Channel extends AppModel {
}