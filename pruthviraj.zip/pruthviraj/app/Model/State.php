<?php
App::uses('AppModel', 'Model');
class State extends AppModel
{
    public $actsAs = array('Containable');
    public $name = 'State';
    public $useTable = 'States';
    public $primaryKey = 'id';
    
    public function search($tablerequest)
    {    
        $search=isset($tablerequest['search']['value'])?$tablerequest['search']['value']:'';    
        
        $total_filtered = $this->find('count', array(
                'fields' => array(
                                'id',
                                'name'),
                'conditions'=>array(
                    'lower(State.name) LIKE' => '%'.strtolower($search).'%')
        ));
        
        
        $data = $this->find('all', array(
                'fields' => array(
                                'id',
                                'name'),
                'conditions'=>array(
                                'State.name LIKE' => '%'.$search.'%'),
                'offset' => $tablerequest['start'],
                'limit' => $tablerequest['length'])
        );
        
        $filtered=[];
        if(count($data)>0){
            $data=!empty($data)?Set::extract('/State/.', $data):null;
            $sr=1;
            foreach($data as $d)
                $filtered[]=array(
                                $sr++,
                                $d['id'],
                                $d['name']);
        }

        
        $json_data = array(
                        'draw'=>$tablerequest['draw'],
                        "recordsTotal" => $this->find('count'),
                        "recordsFiltered" => $total_filtered, 
                        "data"=> $filtered);
                                      
        return $json_data;
        
    }
}