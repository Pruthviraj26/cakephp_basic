<?php
App::uses('AppModel', 'Model');

class Language extends AppModel {
    
    
   public function beforeSave($options = array()) {
       
        if (isset($this->data[$this->alias]['password'])) {
            $this->data[$this->alias]['password'] = AuthComponent::password($this->data[$this->alias]['password']);
        }

        return parent::beforeSave($options);
    }
}