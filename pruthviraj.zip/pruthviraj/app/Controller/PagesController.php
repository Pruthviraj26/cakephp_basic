<?php

App::uses('AppController', 'Controller');

class PagesController extends AppController {
    
    public $uses = array();
	public $components = array('Paginator','Image');    
    public function beforeFilter()
    {
        parent::beforeFilter();
         $this->Auth->allow('home');
    }
    
    public function admin_home($usertype = null) 
    {
        $this->setBackend();
        $breadcrumbs = array();
        $breadcrumbs['Home'] = 'Home';
        $this->set('breadcrumbs',$breadcrumbs);        
        $this->set("pagetitle","Home");
        $this->set("viewtitle","Welcome to learningCake Admin Panel!");       
    }
    
    public function home() 
    {
        
        $this->setFrontend();
		
        $breadcrumbs = array();
        $breadcrumbs['Home'] = 'Home';
        $this->set('breadcrumbs',$breadcrumbs);
        
        $this->set("pagetitle","Home");
        $this->set("viewtitle","ChessCake");        
        $this->set("viewsubtitle","practice makes perfect!");        
        
        $this->LoadModel('News');
        $this->LoadModel('Banner');
        
        
        $banners = $this->Banner->find('all', array(
        'fields'=>array('banner.id','banner.title','banner.subtitle','banner.image','banner.content','banner.source_url'),
        'conditions'=>array('status'=>ACTIVE),
        //'order' => 'News.id'
        ));
        
        
		
        $latestArticales = $this->News->find('all', array(
        'fields'=>array('News.id','News.title','left(News.content,280) as content','News.image'),
        'conditions'=>array('News.type'=>ARTICALE,'status'=>ACTIVE),
        'order' => 'News.id'));
        
                
        $latestVideos = $this->News->find('all', array(
        'fields'=>array('News.id','News.title','News.image','News.source_url'),
        'conditions'=>array('News.type'=>VIDEO,'status'=>ACTIVE),
        'order' => 'News.id'));
        		
		$banners = Set::extract('/Banner/.',$banners);
		
		
		/* array_walk($banners,function(&$key){		
		$src=$key['image'];
			$key['image']=$src;			
		}); */

        $this->set('banners',$banners);
        $this->set('latestArticales',$latestArticales);
        $this->set('latestVideos',$latestVideos);
    }  
    
}
