<?php

App::uses('AppController', 'Controller');
App::uses('CakeEmail', 'Network/Email');
class AngularmaterialsController extends AppController {
    public function autocomplete(){
        $this->setAngular();
    }
    public function demo_custom_template(){
        $this->setAngular();
    }
    
}



