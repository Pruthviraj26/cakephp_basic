<?php

App::uses('AppController', 'Controller');
App::uses('CakeEmail', 'Network/Email');
class UsersController extends AppController {
    public $uses = array();
    
    
    var $helpers = array('Image');
    
    public function beforeFilter()
    {
        parent::beforeFilter();
            $this->Auth->allow('admin_login','admin_forgotpassword','admin_index','getlist');        
    }
    
    public function admin_add() 
    {
        
            /*            
            
            $this->loadModel('Soya');
            $this->paginate = array(
            'conditions' => array('Grupo.categoria' => 'Soya',
                'Grupo.subcategoria' => 'Productor de Oleaginosas'),
            'limit' => 25);
            $this->set(array('soyas', $this->paginate('Soya')));*/
            
        $this->setBackend();
        if ($this->request->is('post')) {
            
            $Email = new CakeEmail();
            $Email->config('gmail');
            $Email->to($this->request->data['email']);
            $Email->subject('Credential for Login');
            $Email->from(EMAIL_FROM);  
            
            
            if ($Email->send()){   
                
                if($this->User->save($this->request->data)) {                     
                    $this->Session->setFlash('Credential has been to sent to user!', 'default', array('class'=>'alert alert-success'), 'success');
            }
            else{
                    $this->Session->setFlash('Something is wrong!', 'default', array('class'=>'alert alert-danger'),'bad');
            }
                
        }
        else
        {
            echo 'email is not sent!';
        }
                
            
            
            
        }
        
        $languages = $this->User->Language->find('all',
                                            array('contain'=>array('Language'))
                                            );
        
        $breadcrumbs = [];
        $breadcrumbs[] = 'Home';
        $breadcrumbs[] = 'Users';
        $breadcrumbs[] = 'Add';
            
        $this->set('languages',$languages);
        $this->set('breadcrumbs',$breadcrumbs);
        
        $this->set("pagetitle","Add User");
        $this->set("viewtitle","Manage User");
        $this->set("viewsubtitle","Add new Admin");
        
    }

    
    public function admin_login() 
    { 
        $this->theme="backend";
        $this->layout='backend_login_layout';
        //$this->setBackend();
        
        if($this->request->is('post')) {
            //$this->request->data['password'] = AuthComponent::password($this->request->data['password']);
			$user = $this->User->find('first',array(
				'contain'=>array(),
				'conditions'=>array(
					'User.email'=>$this->request->data['email'],
                    'User.password'=>$this->request->data['password'])
			));
            
                if(!empty($user)) {
                    if($this->Auth->login($user))
                    {
                        $this->Session->write('User.Type', 'Admin');
                        $this->redirect($this->Auth->redirect());
                    }
                               
                }
                else
                {
                    $this->Session->setFlash('Wrong login, Plz try again!', 'default', array('class'=>'alert alert-danger'), 'bad');
                }
                
        }
    }
    
    public function admin_forgotpassword() 
    {
        $this->theme="front";
        $this->layout='front_main_layout';        
        $breadcrumbs = array();
        $breadcrumbs['Home'] = 'Home';
        $this->set('breadcrumbs',$breadcrumbs);        
        $this->set("pagetitle","Forgot Password");
        $this->set("viewtitle","");        
        $this->set("viewsubtitle","");
    }
    
    public function admin_index()
    {
        $this->setBackend();
        $breadcrumbs = array();
        $breadcrumbs[] = 'Users';
        $this->set('breadcrumbs',$breadcrumbs);

        $users=$this->User->find('all');
        $this->set('users',$users); 
        $this->set("pagetitle","User");
        $this->set("viewtitle","All Users");        
        $this->set("viewsubtitle","");
    }
    
    public function admin_delete()
    {
        $response=[];
        $msg='fail';
        $data='';
        $this->autoRender = false;
        
        $userid = $this->request->params['pass'][0];
        
        $counter = $this->User->find('count',array('conditions' => array('User.id' => $userid)));

        if($counter>0)
            if(true){        
                $status='success';
                $data= $userid;
            }else{
                $status='error';                
            }
        else{
            $status='notfound';
            $data=$this->request->here;
        }
            
        
        //return $this->redirect(['controller'=>'Users','action'=>'index','admin'=>true,$msg]);
        
        $response['status'] = $status;
        $response['data'] = $data;
        
        echo json_encode($response);
    }
    
    public function admin_logout() 
    {
         return $this->redirect($this->Auth->logout());
    }

    public function getlist()
    {
        if($this->request->is('post'))
        {   $this->autoRender = false;
            $response=[];
            $searchInput='';
            $page = $this->request->data['page'];
            $limit = $this->request->data['limit'];
             
            if($this->request->data['searchInput']!=''){
                    
                    $searchInput = $this->request->data['searchInput'];
                    $conditions = array ('OR' => array(array('User.title Like' => '%'.$searchInput.'%'),
                                array('User.subtitle Like' => '%'.$searchInput.'%'),
                                array('User.content Like' => '%'.$searchInput.'%')));
            }
            else{
                $conditions=[];
            }
            
            //print_r($conditions);
            
            $this->paginate = array(
            'contain'=>array('User'),
            'limit' => $limit,
            'page' => $page,
            'conditions'=>$conditions,
            'order' => 'User.id ASC');
      
            $Users = $this->paginate('User');
            $totalUsers= $this->User->find('count');
           
           $Users = Set::extract('/User/.',$Users);
           $paging = Set::extract('User',$this->params['paging']);           
           $response['status']='success';
           $response['data']['Users']=$Users;
           $response['data']['paging']=$paging;
           
           echo json_encode($response);
        }
        
    }
    
    
}




