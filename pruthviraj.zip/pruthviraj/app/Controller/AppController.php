<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {
    
    public $front_theme = '';
    public $front_main_layout='';
    public $admin_theme = '';
    public $admin_main_layout='';
    public $components = array(
    'RequestHandler',
    'Session',
    'Auth' => array(
        'loginRedirect' => array('controller' => 'banners', 'action' => 'index'),
        'logoutRedirect' => array('controller' => 'users', 'action' => 'login'),
        'authenticate' => array(
            'Form' => array(
                'userModel' => 'User',
                'fields' => array('username' => 'email','password'=>'password')
            )
        ),
        'authError' => 'You must be logged in to view this page.',
        'loginError' => 'Invalid Username or Password entered, please try again.'
 
    ));
    
    public function beforeFilter()
    {
        //Application level declaration 
        $copyright='copyright@chesscake.com';
        $this->set("copyright",$copyright);        
        $this->set('authUser', $this->Auth->user());        
		Configure::write('Config.language', $this->Session->read('Config.language'));
        
    }
    
    public function setFrontend()
    {
        $this->theme="frontend";
        $this->layout='frontend_main_layout';
    }
    
    public function setBackend()
    {
        $this->theme="backend";
        $this->layout='backend_main_layout';  
    }
    
    public function setAngular()
    {
        $this->theme="backend";
        $this->layout='backend_angular_layout';  
    }
    
    function sendemail($subject, $body, $to, $template) {
        
        $this->Email->delivery = 'smtp';
        //$this->Email->delivery = 'debug';
        $this->Email->from    = 'Pruthviraj <pruthviraj848@gmail.com>';
        $this->Email->to      = $to;
        $this->Email->subject = $subject;
        $this->set('body', $body);
        $this->set('smtp_errors', $this->Email->smtpError);
        $this->Email->send($content, $template);
    }
    
    
    
    
    
}
