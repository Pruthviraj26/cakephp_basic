<?php
	App::uses('AppController', 'Controller');
	class ChannelsController extends AppController {        
    public $uses = array();    
    public $components = array('Paginator','Image');    
    public $helpers = array('Image',);
	
    public function beforeFilter()
    {
        parent::beforeFilter();
            $this->Auth->allow();
    }
    
    public function admin_index()
    {       
		$this->setBackend();		
        $this->set('viewtitle','Channels');
    }
	
	public function getlist()
	{
		if($this->request->is('post'))
        {   $this->autoRender = false;
			$response=[];
			$searchInput='';
			$page = $this->request->data['page'];
			$limit = $this->request->data['limit'];
			 
			if($this->request->data['searchInput']!=''){
					
					$searchInput = $this->request->data['searchInput'];
					$conditions = array ('OR' => array(array('Channel.title Like' => '%'.$searchInput.'%'),
								array('Channel.subtitle Like' => '%'.$searchInput.'%'),
								array('Channel.content Like' => '%'.$searchInput.'%')));
			}
			else{
				$conditions=[];
			}
			
			//print_r($conditions);
			
			$this->paginate = array(
            'contain'=>array('Channel'),
            'limit' => $limit,
			'page' => $page,
			'conditions'=>$conditions,
            'order' => 'Channel.id ASC');
	  
			$Channels = $this->paginate('Channel');
			$totalChannels= $this->Channel->find('count');
		   
		   $Channels = Set::extract('/Channel/.',$Channels);
		   $paging = Set::extract('Channel',$this->params['paging']);		   
		   $response['status']='success';
		   $response['data']['Channels']=$Channels;
		   $response['data']['paging']=$paging;
		   
		   echo json_encode($response);
		}
		
	}
    
    public function admin_add()
    {        
		$this->setBackend();
        if($this->request->is('post'))
        {   //print_r($this->request->data);die;
            $image=$this->request->data['image'];                   
            $this->request->data['image']=basename($image['name']);                        
			
            if(move_uploaded_file($image['tmp_name'],THUMBNAIL_IMG_PATH.basename($image['name'])))
            {
				
				
				$this->Image->load(THUMBNAIL_IMG_PATH.basename($image['name']));
				$this->Image->resize(THUMBNAIL_IMG_WIDTH,THUMBNAIL_IMG_HEIGHT,'w');
				$this->Image->save(THUMBNAIL_IMG_PATH.basename($image['name']));
			    if($this->Channel->save($this->request->data))
			    {
				   $this->redirect(
					array('controller' => 'Channels', 'action' => 'index','admin'=>true));
			    }
            }
            
        }
        
        
        $breadcrumbs = [];
        $breadcrumbs[] = 'Home';
        $breadcrumbs[] = 'Channels';
        $breadcrumbs[] = 'Add';
                
        $this->set('breadcrumbs',$breadcrumbs);                        
        $this->set("pagetitle","Add Channels");
        $this->set("viewtitle","Add Channels");
        $this->set("viewsubtitle","#");    
    }
    
    
    public function admin_edit()
    {        

		if($this->request->is('get'))
        {
			echo 'get';
            $this->setBackend();            
			$Channelid = $this->request->params['pass'][0];
            $Channel = $this->Channel->find('first',array('conditions'=>array('Channel.id'=>$Channelid)));            
			$Channel = Set::extract('Channel',$Channel);
            $this->set('Channel',$Channel);
			$this->set('viewtitle','Edit Channel');
        }
		
        if($this->request->is('post'))
        {   $response=[];
			$this->autoRender = false;
			
			if(isset($this->request->form))
			{		
				$Channelid=$this->request->data['id'];
				$image=$this->request->form['image'];
				
				$result=$this->Channel->find('first',array('conditions'=>array('id'=>$Channelid)));
				$old_image=$result['Channel']['image'];
				$new_image=basename($image['name']);
					
				if(move_uploaded_file($image['tmp_name'],THUMBNAIL_IMG_PATH.$new_image))
				{
					$result=false;
					
					
					$this->Image->load(THUMBNAIL_IMG_PATH.basename($image['name']));
					$this->Image->resize(THUMBNAIL_IMG_WIDTH,THUMBNAIL_IMG_HEIGHT,'w');
					$result = $this->Image->save(THUMBNAIL_IMG_PATH.$new_image);
					
					$this->Channel->id = $Channelid;
				    $this->request->data['image']=$new_image;
					$result = $this->Channel->save($this->request->data);
					
					if($result)
					{
						if($old_image!=$new_image)
						{							
							if(file_exists(THUMBNAIL_IMG_PATH.$old_image))
								unlink(THUMBNAIL_IMG_PATH.$old_image);
						}
					}
									   
				   if($result)
				   {
					   
					   $response['status']='success';
					   $response['data']['img'] = $new_image;
					   $response['data']['msg'] = __('image').' '.__('has been updated successfully!');
					   
				   }
				   else{
					   $response['status']='fail';
					   $response['data']['msg'] = __('err_msg');					   
				   }
				}
				echo json_encode($response);
				die;
			}
			
			if(isset($this->request->data))
			{				
				$this->Channel->id=$this->request->data['id'];
				$result = $this->Channel->save($this->request->data);
				if($result)
				   {
					   
					   $response['status']='success';					   
					   $response['data']['msg'] = $this->request->data['field'].' '.__('has been updated successfully!');
				   }
				   else{
					   $response['status']='fail';
					   $response['data']['msg'] = __('err_msg');					   
				   }
				echo json_encode($response);
				die;
			}
			
			
        }
    }
    
    
    public function admin_delete()
    {
        $response=[];
        $msg='fail';
        $data='';
        $this->autoRender = false;
        
        $Channelid = $this->request->params['pass'][0];
        $first = $this->Channel->find('first',array('conditions' => array('Channel.id' => $Channelid)));
        
		$counter = count($first['Channel']);
		
        $imgname = $first['Channel']['image'];
        if($counter>0)
        {
            $this->Channel->id=$Channelid;
            if($this->Channel->delete(array('id'=>$Channelid))){ 
                
                $status='success';
                $data=$imgname;
            }else{
                $status='error';
            }
            
        }
        else{
            $status='notfound';
            $data=$this->request->here;
        }

        $response['status'] = $status;
        $response['data'] = $data;
        
        echo json_encode($response);
    }
    
    public function admin_delete_images()
    {
        $imgname = $Channelid = $this->request->params['pass'][0];
        
      
		if(file_exists(THUMBNAIL_IMG_PATH.$imgname))
			unlink(THUMBNAIL_IMG_PATH.$imgname);
                
    }
    
    
    public function admin_status_toggle()
    {
        $response=[];
        $status='fail';
        $data='';
        $this->autoRender = false;
        
        $Channelid = $this->request->params['pass'][0];
        
        $counter = $this->Channel->find('count',array('conditions' => array('Channel.id' => $Channelid)));

        if($counter>0)
        {
            $this->Channel->id=$Channelid;
            
            
            $first=$this->Channel->find('first', array(
                'fields'=>array('Channel.status'),
                'conditions' => array('Channel.id' => $Channelid)
            ));
            
            
            
            if($first['Channel']['status']==ACTIVE)
            {
                if($this->Channel->save(array('status'=> INACTIVE)))
                {
                    $status='success';
                    $isActive=false;
                }
            }else{
                if($this->Channel->save(array('status'=> ACTIVE)))
                {
                    $status='success';
                    $isActive=true;
                }
            }
   
        }
        else{
            $status='notfound';
        }
        $response['status'] = $status;
        $response['isActive']=$isActive;
        echo json_encode($response);
    }
        
    public function articale()
    {
        $this->setFontend();    
    }
    
}

