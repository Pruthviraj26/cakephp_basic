<?php

App::uses('AppController', 'Controller');
class angularController extends AppController {
    

    public function index() 
    {
        $this->theme="front";
        $this->layout='front_main_layout';
        
        $breadcrumbs = array();
        $breadcrumbs['Home'] = 'Home';
        $this->set('breadcrumbs',$breadcrumbs);
        
        $this->set("pagetitle","Forgot Password");
        $this->set("viewtitle","");        
        $this->set("viewsubtitle","");   
    }
    
    
    
        
	
}
