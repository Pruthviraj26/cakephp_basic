<?php
	App::uses('AppController', 'Controller');
	class LanguagesController extends AppController {        
    public $uses = array();    
    public $components = array('Paginator','Image');    
    public $helpers = array('Image',);
	
    public function beforeFilter()
    {
        parent::beforeFilter();
            $this->Auth->allow();
    }
    
    public function admin_index()
    {       
		$this->setBackend();		
        $this->set('viewtitle','Languages');
    }
	
	public function getlist()
	{
		if($this->request->is('post'))
        {   $this->autoRender = false;
			$response=[];
			$searchInput='';
			$page = $this->request->data['page'];
			$limit = $this->request->data['limit'];
			 
			if($this->request->data['searchInput']!=''){
					
					$searchInput = $this->request->data['searchInput'];
					$conditions = array ('OR' => array(array('Language.title Like' => '%'.$searchInput.'%')));
			}
			else{
				$conditions=[];
			}
			
			//print_r($conditions);
			
			$this->paginate = array(
            'contain'=>array('Language'),
            'limit' => $limit,
			'page' => $page,
			'conditions'=>$conditions,
            'order' => 'Language.id ASC');
	  
			$Languages = $this->paginate('Language');
			$totalLanguages= $this->Language->find('count');
		   
		   $Languages = Set::extract('/Language/.',$Languages);
		   $paging = Set::extract('Language',$this->params['paging']);		   
		   $response['status']='success';
		   $response['data']['Languages']=$Languages;
		   $response['data']['paging']=$paging;
		   
		   echo json_encode($response);
		}
		
	}
	
	public function admin_add()
	{
		$this->autoRender = false;
		$this->Language->save($this->request->data);
	}
    
    public function admin_delete()
    {
        $response=[];
        $msg='fail';
        $data='';
        $this->autoRender = false;        
        $Languageid = $this->request->data['id'];		
        $counter = $this->Language->find('count',array('conditions' => array('Language.id' => $Languageid)));		
        if($counter>0)
        {
            $this->Language->id=$Languageid;
            if($this->Language->delete(array('id'=>$Languageid))){ 
                $status='success';                
            }else{
                $status='error';
            }
        }
        else{
            $status='notfound';
        }
        $response['status'] = $status;
        $response['data'] = $data;
        echo json_encode($response);
    }
    
    
    public function admin_status_toggle()
    {
        $response=[];
        $status='fail';
        $data='';
        $this->autoRender = false;
        
        $Languageid = $this->request->params['pass'][0];
        
        $counter = $this->Language->find('count',array('conditions' => array('Language.id' => $Languageid)));

        if($counter>0)
        {
            $this->Language->id=$Languageid;
            
            
            $first=$this->Language->find('first', array(
                'fields'=>array('Language.status'),
                'conditions' => array('Language.id' => $Languageid)
            ));
            
            
            
            if($first['Language']['status']==ACTIVE)
            {
                if($this->Language->save(array('status'=> INACTIVE)))
                {
                    $status='success';
                    $isActive=false;
                }
            }else{
                if($this->Language->save(array('status'=> ACTIVE)))
                {
                    $status='success';
                    $isActive=true;
                }
            }
   
        }
        else{
            $status='notfound';
        }
        $response['status'] = $status;
        $response['isActive']=$isActive;
        echo json_encode($response);
    }
        
    
}

