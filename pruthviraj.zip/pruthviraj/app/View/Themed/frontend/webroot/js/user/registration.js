var registrationApp = angular.module('registrationApp',['registrationApp', 'ngMessages', 'material.svgAssetsCache']);
function registrationCtrl($scope, $http) {

     $scope.showHints = true;

    $scope.formData = {};            
    // process the form
    $scope.processForm = function() {
        $http({
            method  : 'POST',
            url     : '<?php echo $this->Html->url(array('controller'=>'Users','action'=>'submit_registration')) ?>',
            data    : $.param($scope.formData),  // pass in data as strings
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' }  // set the headers so angular passing info as form data (not request payload)
        })
            .success(function(data) {
              $scope.message=data;

                if (!data.success) {
                    // if not successful, bind errors to error variables
                    //$scope.errorName = data.errors.name;
                    //$scope.errorSuperhero = data.errors.superheroAlias;
                } else {
                    $scope.errorName = '';                    
                }
            });

    };

}

